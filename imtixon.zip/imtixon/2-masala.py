import threading
import requests
base_url = "https://tilshunos.com/sinonims/"

def page_2_html(args):
    url = base_url + str(args) + "/"
    with open(f"htmlfiles/{args}.html", "wb") as file:
        file.write(requests.get(url).content)
    
    
def main():
    threads = []
    # if you you change the for numbers it parcisng the another pages
    for i in range(51, 61):
        t = threading.Thread(target=page_2_html, args=(i,))
        threads.append(t)
        t.start()
    
    for thread in threads:
        thread.join()
    
    print("I'm done")
    
main()